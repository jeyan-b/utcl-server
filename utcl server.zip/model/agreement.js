const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const CSchema= new Schema({
    startDate: {
        type: Date,
        required: [true, 'Start date field required']
    },
    endDate: {
        type: Date,
        required: [true, 'End date field required']
    },
    billingCycle: {
        type: String,
        required: [true, 'billing cycle is required']
    },
});

const Agreement = mongoose.model('agreement', CSchema, 'agreement');

module.exports = Agreement;