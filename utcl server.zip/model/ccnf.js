const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const CSchema= new Schema({
    commisionRangeFrom: {
        type: Number,
        required: [true, 'Commision range from field required']
    },
    commisionRangeTo: {
        type: Number,
        required: [true, 'Commision range to field required']
    }
});

const CCNF = mongoose.model('ccnf', CSchema, 'ccnf');

module.exports = CCNF;