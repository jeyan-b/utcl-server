const express = require('express');
const router = express.Router();
const Agency = require('../model/agency');
const Agreement = require('../model/agreement');
const CCNF = require('../model/ccnf');

router.get('/agency', async function(req, res, next){
    try {
        const agency = await Agency.find({});
        res.send(agency);
        console.log(agency);
      } catch (err) {
        console.log(err);
      }
});

router.post('/agency', async function(req, res, next){
var newAgency = new Agency({
    vendor: req.body.vendor,
    agencyName: req.body.agencyName,
    state: req.body.state,
    region:req.body.region,
    depot:req.body.depot,
    district: req.body.district,
});
try {
    const agency = await newAgency.save();
    res.send(agency);
    console.log(agency);
  } catch (err) {
    console.log(err);
  }

});

router.post('/agreement', async function(req, res, next){
var newAgreement = new Agreement({
    startDate: req.body.startDate,
    endDate: req.body.endDate,
    billingCycle: req.body.billingCycle
});
try {
    const agreement = await newAgreement.save();
    res.send(agreement);
    console.log(agreement);
  } catch (err) {
    console.log(err);
  }

});

router.post('/ccnfCommision', async function(req, res, next){
var newCcnfConfirmation = new CCNF({
  commisionRangeFrom: req.body.commisionRangeFrom,
  commisionRangeTo: req.body.commisionRangeTo,
});
try {
    const agreement = await newCcnfConfirmation.save();
    res.send(agreement);
    console.log(agreement);
  } catch (err) {
    console.log(err);
  }

});

module.exports = router;